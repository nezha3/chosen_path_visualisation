# chosen_path_visualisation
